package com.cybage.boot.controller;



import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cybage.boot.model.User;
import com.cybage.boot.model.UserWeight;
import com.cybage.boot.service.UserService;


@RestController
@CrossOrigin
public class UserController {

	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService; 
	 
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User u) {
	
	if(userService.findUserByEmailAndPassword(u.getEmail(), u.getPassword())!= null )
	{
		logger.info("Returning User Object for Login");
		return new ResponseEntity<User>(userService.findUserByEmailAndPassword(u.getEmail(), u.getPassword()),HttpStatus.OK);
	}	 
	else
		return new ResponseEntity<String>("Account not found : ", HttpStatus.NOT_FOUND);
	
	}
	
	 @PostMapping("/register")
	 public ResponseEntity<HttpStatus> register(@RequestBody User u) {
		
		if(userService.saveUser(u)) {
			logger.info("Returning status Ok for User Registration");
			return ResponseEntity.ok(HttpStatus.OK);
		}
		else
			return ResponseEntity.ok(HttpStatus.UNAUTHORIZED);
	 }
	 
	 @PostMapping(value="/addweight/{uId}")
	 public ResponseEntity<HttpStatus> addSubCategory(@PathVariable("uId") int uId,
	                                 @Valid @RequestBody UserWeight weight) {
		
		 if(userService.addWeight(weight, uId))
		 {
			 logger.info("Payload for Add Weight with User Id"+uId+"Weight:"+weight);
			 return ResponseEntity.ok(HttpStatus.OK);
		 }
		 else
	        return ResponseEntity.ok(HttpStatus.BAD_REQUEST);
	    }
	 
		@GetMapping(value="/getweight/{uId}")
		public List<UserWeight> findAllWeight(@PathVariable("uId") int uId){
			List<UserWeight> weights = userService.getUserWeight(uId);
			logger.info("Returning All Weights with User Id"+uId+"Weights"+weights);
			return weights;
		}
	 
		@PutMapping(value="/updateweight")
		public  ResponseEntity<HttpStatus> updateWeight(@RequestBody UserWeight weight)
			{
			logger.info("Payload For Update Weight"+weight);
			if(userService.updateWeight(weight)){
				return ResponseEntity.ok(HttpStatus.OK);	
				}				 
			return ResponseEntity.ok(HttpStatus.BAD_REQUEST);			
			}
	 
		
		
		
		@DeleteMapping(value="/deleteweight/{wId}")
		public ResponseEntity<HttpStatus> deleteWeight(@PathVariable("wId") int wId){
			if(userService.deleteWeight(wId)) {
				logger.info("Data to be Delete with wId"+wId);
				return ResponseEntity.ok(HttpStatus.OK);
			}
			return ResponseEntity.ok(HttpStatus.FORBIDDEN);
		}
	 
}
