package com.cybage.boot.controller;

import com.cybage.boot.repository.ProductRepo;
import com.cybage.boot.model.Customer;
import com.cybage.boot.model.Product;
import com.cybage.boot.repository.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    CustomerRepo repo;
    @Autowired
    ProductRepo prepo;

    @PostMapping("/save")
    public Customer customerSave(@RequestBody Customer customer){
        return repo.save(customer);
    }

    @GetMapping(value = "/")
    public List<Customer> allCustomers(){
        return  repo.findAll();
    }

    @PostMapping("/{id}")
    public Customer findCustomerById(@PathVariable final int id){
        return repo.findByCId(id);
    }


    @PutMapping("/{id}")
    public Customer update(@PathVariable final int id,@RequestBody Customer c){
        Customer cus=  repo.findByCId(id);
        if(cus!= null){
           cus.setName(c.getName());
           cus.setEmail(c.getEmail());
           cus.setGender(c.getGender());
        }
        return repo.save(c);
    }

    @GetMapping("/product/{email}")
    public List<Product> findProductbyemail(@PathVariable String email){
        return prepo.findByCustomerEmail(email);
    }

}
