package com.cybage.boot.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cybage.boot.model.UserWeight;

@Repository
public interface UserWeightRepository extends JpaRepository<UserWeight, Integer> {
	
	List<UserWeight> findByUser1UserId(int id);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM userweight WHERE wId = ?1", nativeQuery = true)
	void deletWeight(int wId);
	
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE userweight SET weight = ?1 WHERE wId = ?2", nativeQuery = true)
	void updateWeight(String weight,int wId);

}
	