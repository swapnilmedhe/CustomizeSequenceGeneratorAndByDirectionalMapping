package com.cybage.boot.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.List;



@Data
@Entity
@Table(name = "customer")
public class Customer {

    @Id
    @NotNull
    @GenericGenerator(name = "seq",strategy = "com.cybage.boot.generator.Seqgenerator")
    @GeneratedValue(generator = "seq")
    @SequenceGenerator(name = "seq",initialValue = 500)
    private String cId;
    private String name;
    private String email;
    private String gender;

   @JsonManagedReference
   @OneToMany(cascade = CascadeType.ALL, mappedBy = "customer",fetch = FetchType.EAGER)
    private List<Product> products;

}
