package com.cybage.boot.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int userId;
	
	@Column(name = "fName")
	String fName;
	
	@Column(name = "lName")
	String lName;
	
	@Column(name = "email", unique=true)
	String email;
	
	@Column(name = "password")
	String password;
	
	@OneToMany(mappedBy = "user1", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Set<UserWeight> weight;

	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public int getuId() {
		return userId;
	}

	public void setuId(int uId) {
		this.userId = uId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@JsonIgnore
	public Set<UserWeight> getWeight() {
		return weight;
	}

	@JsonIgnore
	public void setWeight(Set<UserWeight> weight) {
		this.weight = weight;
	}

	
	
	

}
